import Color from './Color';
import Fonts from './Fonts';
import Strings from './Strings';
import Dimension from './Dimension';

export {Color, Fonts, Strings, Dimension};
