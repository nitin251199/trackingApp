export default {
  primaryLight: 'Poppins-Light',
  primaryRegular: 'Poppins-Regular',
  primaryBold: 'Poppins-Bold',
  primarySemiBold: 'Poppins-SemiBold',
};
